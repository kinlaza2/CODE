
*****************************************************************
*                                                               *
*  04/01/2004 Niagara SCX(TM) V. 3.2.63.1.FCN04 Release Notes   *
*                                                               *
*  Copyright (c) 2004 ViewCast Corporation                      *
*  All rights reserved.                                         *
*                                                               *
*  Niagara(TM) is a registered trademark of ViewCast Corporation*
*                                                               *
*****************************************************************

Introduction:
=============

This Field Change Notice affects the following:

1) Encoding audio only streams under Helix.

2) Status message corrected for encoders that have been started.

NOTES:

Contents:
=========

This FCN contains the following files:

Readme_SCX_FCN04.txt  - This file
Setup.bat             - installer
RealProducer.dll      - Updated library file

Follow these steps to update your system:

Installation:
-------------
1) Stop the Niagara SCX service
2) Close the Niagara Encoder Explorer
3) Install all ViewCast products (setup.bat)
4) Start the Niagara SCX service
5) Start the Niagara Encoder Explorer

-- end



