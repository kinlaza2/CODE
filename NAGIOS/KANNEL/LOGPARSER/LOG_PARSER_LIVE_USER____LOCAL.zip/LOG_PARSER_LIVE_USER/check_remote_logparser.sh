#! /bin/bash

USER=nagios
PASSWORD=nagios
LIBEXEC="/home/nagios/nagios/libexec"
REMOTE_EXEC="/home/nagios/monitoring/libexec/CUSTOM/LOG_PARSER_LIVE_USER"

$LIBEXEC/check_by_ssh -H $1 -t 160 -C "$REMOTE_EXEC/nagios_log_parser_ctrl.sh $REMOTE_EXEC/${2}  ${3}" 


