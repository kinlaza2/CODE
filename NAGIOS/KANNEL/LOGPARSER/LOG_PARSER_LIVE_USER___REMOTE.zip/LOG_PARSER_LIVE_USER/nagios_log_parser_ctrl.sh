#!/bin/bash

# nagios log parser control script V 0.20
# Designed to control the parser V 0.2X
# comments to hmakripodis@velti.com


# Define the location of the parser
#######################################################

PARSER="/home/nagios/monitoring/libexec/CUSTOM/LOG_PARSER_LIVE_USER/nagios_log_parser.awk"
MAWK="/home/nagios/MAWK_HOME/bin/mawk"

#######################################################

COMMAND=$2
CONFIGFILE=$1

if [[ "$USER" != "nagios" ]]; then
	echo "The parser must be executed as 'nagios' user!"
	exit 1
fi

if [[ -r "$CONFIGFILE" ]] ; then
	source "$CONFIGFILE"
else
	echo "Config file [$CONFIGFILE] cannot be read!"
	exit 1	
fi

PIDFILE="$CONFIGFILE.PID"
DUMMYFILE="$CONFIGFILE.KEEPALIVE"

function AppendPidToFile {
	echo "`date`%$1%$2" >> $3
}

function killProcesses {
	for i in `awk -F% '$2 ~ /[0-9]+/ {print $2}' $PIDFILE` 
	do
		echo -n "Killing PID $i.. " &&  kill $i 2>/dev/null && echo "Done " || echo "Failed "
	done  
	rm $PIDFILE 2>/dev/null || echo "Cannot remove PID file $i .."
}


function control_c {
	echo "Got control-C , exiting.."
	killProcesses
	exit $?
}


function showpid {
	echo "PID file [$PIDFILE] reports:"
	awk -F% '$2 ~ /[0-9]+/ {print $3" component is started with the PID "$2 }' $PIDFILE
}


function checkpid {
	awk -F% '
		BEGIN { exitcode=0 }
		$2 ~ /[0-9]+/ {
			if ($3) {
				count++
				getpid="ps -p "$2" &>/dev/null"
				exitcode+=system(getpid)
				close(getpid)
			}
		} 
		END { 

			 if(count !=3 || exitcode != 0 ) exit 1
		} 
	' $PIDFILE
}
 

trap control_c SIGINT
 



##############################################


case "$COMMAND" in
	start)
		echo -n "Starting plugin $CONFIGFILE.. "
		if [[ -r "$PIDFILE" ]] ; then
			echo -e "Failed.\nPID file $PIDFILE already exists! The parser is running or the PID file is stale."
			exit 1
		fi


                nohup bash -c "while sleep $keepalive ; do echo '___Nagios___' ; done" > $DUMMYFILE 2>/dev/null &
                AppendPidToFile $! "Keepalive" $PIDFILE


		nohup tail -q -F -n 1 $logfile $DUMMYFILE | $MAWK -W interactive -f $PARSER -v configfile=${CONFIGFILE} &


		awkPid=$!
		AppendPidToFile $awkPid "Parser" $PIDFILE

        	pipePid=$(ps -fe | awk -v logfile=${logfile} -v parrent=${$} '
                BEGIN { 
			count=0
			pattern="tail -q -F -n 1 "logfile
		}
                $1 == "nagios" && $3 == parrent && $8 == "tail" && $0 ~ pattern { 
			pid=$2
			count++ 
		}
                END { 
			if(count==1) { print pid } else { print "-1" } 
		} ')

		if [[ "$pipePid" -ne "-1" ]]
		then
			AppendPidToFile $pipePid "Pipe" $PIDFILE
		else
			echo -e "Failed.\nCannot find process or multiple processes detected for the 'tail' command.\nPlease check manually the processes table.\nRun this script again with 'stop' command to clean up the processes"
			exit 1
		fi
		echo " Done"
		exit 0
	;;


	stop)
	        if [[ -r "$PIDFILE" ]] ; then
	                showpid
	                killProcesses
			rm $DUMMYFILE
	        else
	                echo "PID file $PIDFILE does not exist"
	        fi
		echo "Stopping plugin $CONFIGFILE.. Done"
		exit $?
	;;



	status)
		echo "Showing status for plugin $CONFIGFILE" 	
	        if [[ -r "$PIDFILE" ]] ; then
	                showpid
			checkpid
                        if [[ $? -ne 0 ]] ; then
                                echo "Wrong processes listed on $PIDFILE file!"
                                exit 1
                        fi
	        else
	                echo "PID file $PIDFILE does not exist"
			exit 2
	
	        fi
	;;


	quickstatus)
                if [[ -r "$PIDFILE" ]] ; then
                        checkpid
			if [[ $? -ne 0 ]] ; then
				echo "---Failed---"
				exit 1	
			fi
                else 
				echo "---Failed---"
                        	exit 127
                fi
		echo "---OK---"
        ;;

	*)
		echo "Wrong options."
		echo "Syntax: $0 <config file> <start|stop|status|cronstatus|quickstatus>" 
		exit 1
	;;

esac

exit 0
