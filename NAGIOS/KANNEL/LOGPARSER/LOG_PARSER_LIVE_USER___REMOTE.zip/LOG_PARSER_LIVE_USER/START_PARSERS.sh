SCRIPTS_PATH=/home/nagios/monitoring/libexec/CUSTOM/LOG_PARSER_LIVE_USER/

for i in  parser_CC_SERVER_LOG.properties parser_MSGRECEIVER_BILLING_APPLICATION_LOG.properties   parser_MSGRECEIVER_SERVERLOG.properties  parser_PLATFORM.properties  parser_PLATFORM_SERVERLOG.properties

do
$SCRIPTS_PATH/nagios_log_parser_ctrl.sh  $i start
sleep 1
done

