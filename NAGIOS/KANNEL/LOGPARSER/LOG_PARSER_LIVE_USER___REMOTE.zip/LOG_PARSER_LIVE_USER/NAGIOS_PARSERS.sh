HOME_PATH=/home/nagios/monitoring/libexec/CUSTOM/LOG_PARSER_LIVE_USER 
PROPERTIES_FILE_LIST="parser_CMS.properties"


######################################################################################


start()
{
for i in `echo $PROPERTIES_FILE_LIST`
do
        $HOME_PATH/nagios_log_parser_ctrl.sh $i status > /dev/null
        if [ $? -eq 0 ]
        then
                echo "Parser "$i" is already UP"
                return 0;
        else
                echo "Parser "$i" was DOWN. Trying to start it."
                $HOME_PATH/nagios_log_parser_ctrl.sh $i start > /dev/null
                sleep 1;
                $HOME_PATH/nagios_log_parser_ctrl.sh $i status > /dev/null
                if [ $? -eq 0 ]
                then
                        echo "Parser "$i" was STARTED"
                        return 0;
                else
                        echo "An unexpected problem was appearead trying to start parser "$i" "
                        return 1;
                fi
        fi

done
}




stop()
{
for i in `echo $PROPERTIES_FILE_LIST`
do
        $HOME_PATH/nagios_log_parser_ctrl.sh $i status > /dev/null
        if [ $? -eq 0 ]
        then
                echo "Parser "$i" is UP. Trying to stop it."
		$HOME_PATH/nagios_log_parser_ctrl.sh $i stop > /dev/null
		sleep 1;
		$HOME_PATH/nagios_log_parser_ctrl.sh $i status > /dev/null
		if [ $? -eq 0 ]
		then
			echo "An unexpected problem was appearead trying to stop parser "$i" "
			retrun 1;	
		else
			echo "Parser "$i" was STOPPED"
			return  0;
                fi
        else
                echo "Parser "$i" was DOWN."
		return 0;
        fi

done
}


status ()
{
for i in `echo $PROPERTIES_FILE_LIST`
do
        $HOME_PATH/nagios_log_parser_ctrl.sh $i status > /dev/null
        if [ $? -eq 0 ]
        then
                echo "Parser "$i" is UP."
        else
                echo "Parser "$i" is DOWN."
        fi

done
return 0;
}



case $1 in
        start)
		start
		;;

        stop)   
		stop
		;;

        status)
		status
		;;
        *)                	
		echo "Wrong options."                
		echo "Syntax: $0 <config file> <start|stop|status>"                
		exit 1 
		;;       
esac


